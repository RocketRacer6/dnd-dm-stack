# 🤖 D&D DM Bot - Info

## Bot Details

**Name:** D&D_dm
**Username:** @DnDgameBot
**Token:** 8540431490:AAGifeB8iG5bc78aOaqMFYLbWy0iEncow0E

---

## 🎮 How to Find Your Bot

1. Open Telegram
2. Search for: `@DnDgameBot`
3. Click to open chat
4. Send `/start`

---

## 📝 First Commands

```
/start          - Welcome message
/newgame <name> - Create campaign
/roll d20       - Roll dice
/dm <action>    - Tell DM what you want to do
/help           - All commands
```

---

## 🎲 Quick Example Game

```
/start
/newgame The Lost Mine of Phandelver
/roll d20
/dm I want to search the room for traps
```

---

**Ready to adventure! 🧡**
